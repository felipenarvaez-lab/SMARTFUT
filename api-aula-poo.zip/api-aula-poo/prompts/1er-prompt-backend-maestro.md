Actúa como un desarrollador senior y estudiante de Programación Orientada a Objetos. Necesito construir un proyecto académico en Java con Spring Boot para segundo semestre, con enfoque en POO aplicada y API REST simple.

Quiero que generes un proyecto backend con estas condiciones obligatorias:

OBJETIVO:
Construir un API REST para gestionar Usuarios y Productos.

REQUISITOS FUNCIONALES:
1. CRUD completo de Usuario
2. CRUD completo de Producto
3. Endpoint GET /health

ARQUITECTURA OBLIGATORIA:
- controller
- service
- repository
- model
- dto
- exception

RESTRICCIONES OBLIGATORIAS:
- No usar base de datos
- No usar JPA ni Hibernate
- No usar relaciones entre entidades
- Persistencia solo en memoria con Map<Long, ...>
- No poner lógica de negocio en controllers
- No exponer entidades directamente en la API; usar DTO
- Debe haber validaciones básicas
- Debe haber manejo de errores para 400 y 404
- El código debe ser sencillo, claro y apropiado para estudiantes de segundo semestre
- No usar patrones complejos
- No usar Lombok por ahora, a menos que se indique lo contrario

ENTIDAD USUARIO:
- id: Long
- nombre: String
- correo: String
- edad: int

Reglas:
- nombre no vacío
- correo debe contener @
- edad debe ser mayor a 0

ENTIDAD PRODUCTO:
- id: Long
- nombre: String
- precio: double
- stock: int

Reglas:
- nombre no vacío
- precio mayor que 0
- stock no negativo

LO QUE NECESITO DE TI:
1. Proponer la estructura de paquetes
2. Generar el código completo por archivos
3. Explicar brevemente la responsabilidad de cada clase
4. Incluir DTO de request y response
5. Incluir excepciones personalizadas
6. Incluir un GlobalExceptionHandler
7. Incluir repositorios en memoria con Map y generación simple de id
8. Incluir ejemplos de endpoints
9. Incluir ejemplos JSON para probar en Postman
10. Entregar primero un plan de archivos antes de generar el código

IMPORTANTE:
Quiero que trabajes paso a paso.
Primero muestra la estructura completa del proyecto y explica qué hará cada archivo.
Después genera el código archivo por archivo.
No simplifiques saltándote capas.
No tomes decisiones avanzadas que no hayan sido pedidas.